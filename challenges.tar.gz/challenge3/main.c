#include<stdio.h>

int main() {
	/*
	  Looks like this program wont even compile.
	  Remove the bug and submit your changes!
	*/ 
	printf("Hello World\n");
	BUG
	return 0;
}
